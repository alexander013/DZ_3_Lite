# Кортеж - незмениямый "список"

# Объявление кортежа
friends = ('max', 'kate', 'john', 'leo')
friends = 'max', 'kate', 'john', 'leo'

print(type(friends))

roles = ('admin', 'guest')