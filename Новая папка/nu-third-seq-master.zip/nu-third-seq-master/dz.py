# 1. Понятные названия переменных
question_1 = 'Год рождения?'
# question_year
# year
# a = 'Год рождения?'
# 2. Объявление переменных рядом с местом использования

PUSHKIN_BIRTHDAY_YEAR = 1799
PUSHKIN_BIRTHDAY_DAY = 26

year = '1999'
while year > 0:
    pass

day = '26'
while day < 100:
    pass

# 3. Переменную под количество ответов 5
# questions_count = 10
# 3 * 100 / questions_count
# 2 * 100 / questions_count

# 4. Переменные в camelCase,
birthdayYear = 1799
# pep8
birthday_year = 1799

# BirthdayYear = 1799

